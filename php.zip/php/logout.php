<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<script type="text/javascript">
window.location.href="../html/home.html";
</script>
<body>
<?php
session_start();
session_destroy();
?>
</body>
</html>